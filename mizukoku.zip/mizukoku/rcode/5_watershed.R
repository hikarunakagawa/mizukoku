setwd("dir/mizukoku")

library(sf)
library(maptools)
library(rgdal)
library(ggplot2)

data01<-read_sf(paste0(getwd(),"/output/SHP/Watershed2.shp"))
data02<-read_sf(paste0(getwd(),"/output/SHP/Watershed_Elv.shp"))
data03<-read_sf(paste0(getwd(),"/output/SHP/Watershed_LandUse.shp"))

data03$森林<-ifelse(data03$森林>data03$Watershed_area,data03$Watershed_area,data03$森林)

Watershed_area<-round(tapply(data01$Watershed_area,data01$W12_002,mean,na.rm=TRUE)/1000000,1)
Slope<-round(tapply(data02$Slope,data02$W12_002,mean,na.rm=TRUE),1)
Elv<-round(tapply(data02$Elv,data02$W12_002,mean,na.rm=TRUE),1)
Forest<-tapply(data03$森林,data03$W12_002,sum,na.rm=TRUE)/1000000
Forest<-round(Forest/Watershed_area,3)*100
t<-rbind(Watershed_area,Slope,Elv,Forest)
colnames(t)<-c("Chiyo","Tenjin","Hino","Hii","Gono","Takatsu","Yoshii","Asahi","Takahari","Asida","Ohota","Oze","Saba",
               "Yoshino","Naka_Shikoku","Doki","Shigenobu","Hiji","Monobe","Niyodo","Shimanto")

t<-data.frame(t(t))
t$River<-rownames(t)

write.csv(t,paste0(getwd(),"/output/CSV/watershed.csv"),fileEncoding="UTF8",row.names=FALSE)
