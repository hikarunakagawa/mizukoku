setwd("dir/mizukoku/rawdata/download")

library("rvest")
library(tidyr)
library(tidyverse)
library(ggplot2)

id01<-c(
  10801, #重信川
  10802, #肱川
  10803, #四万十川
  10804, #仁淀川
  10805, #物部川
  10806, #那賀川
  10807, #吉野川
  10808, #土器川
  10701, #千代川
  10702, #天神川
  10703, #日野川
  10704, #斐伊川
  10705, #江の川
  10706, #高津川
  10707, #佐波川
  10708, #小瀬川
  10709, #太田川
  10710, #芦田川
  10711, #高梁川
  10712, #旭川
  10713 #吉井川
)
id02<-c(128880,
        128881,
        128770,
        128771
)

id03<-list()
p<-0
for(k in 1:length(id01)){
  for(l in 1:length(id02)){
    for(i in 1:9999){
      p<-p+1
      id03[[p]]<-paste0(id01[k],id02[l],formatC(i,width=4,flag="0"))
    }}}

f<-function(x){
  url <- paste0("http://www1.river.go.jp/cgi-bin/SiteInfo.exe?ID=",x)
  html<-read_html(url)
  tb<-html_table(html)
  ifelse(length(tb)>0,x,NA)
}

list_id<-lapply(id03,try(f))
list_id<-list_id[!sapply(list_id,is.na)]
list_id<-do.call(rbind,list_id)

write.csv(list_id,"/Volumes/HD-ADU3/GIS/Projects/mizukoku/output/CSV/list_id.csv",fileEncoding="UTF8",row.names=FALSE)
list_id<-read.csv("/Volumes/HD-ADU3/GIS/Projects/mizukoku/output/CSV/list_id.csv",fileEncoding="UTF8")

x<-c(2002:2022)
precip<-list()
for(k in 1:nrow(list_id)){
  html_list<-list()
  dat_url<-list()
  flist<-list()
  for(i in 1:length(x)){
    html_list[[i]]<-read_html(paste("http://www1.river.go.jp/cgi-bin/DspRainData.exe?KIND=3&ID=",list_id[k,],"&BGNDATE=",x[i],"0131&ENDDATE=",x[i],"1231&KAWABOU=NO",sep=""))
    dat_url[i] = html_list[[i]] %>%
      html_nodes("a") %>%   ## find all links
      html_attr("href") %>% ## pull out url
      str_subset("\\.dat")  ## pull out dat links
    flist[i]<-download.file(paste("http://www1.river.go.jp",dat_url[i],sep=""),destfile=sub("dat","txt",sub("/dat/dload/download/","",dat_url[i])))
  }
  d<-list()
  for(j in 1:length(x)){
    a<-readLines(file(paste(getwd(),sub("dat","txt",sub("/dat/dload/download/","",dat_url[j])),sep="/"),encoding="SJIS"))
    river<-strsplit(a[2],",")[[1]][2]
    site<-strsplit(a[4],",")[[1]][2]
    a<-a[c(12:23)]
    for(i in 1:length(a)){a[i]<-gsub(" ","",a[i])}
    for(i in 1:length(a)){a[i]<-gsub("\\$","",a[i])}
    for(i in 1:length(a)){a[i]<-gsub("-","",a[i])}
    for(i in 1:length(a)){a[i]<-gsub(",,",",",a[i])}
    for(i in 1:length(a)){a[i]<-gsub("9999.0","",a[i])}
    b<-list()
    for(i in 1:length(a)){b[i]<-strsplit(a[i],",");if(length(b[i])<32)b[i]<-c(b[i],rep("",32-length(b[i])))}
    d[[j]]<-as.data.frame(do.call(rbind,b))
    colnames(d[[j]])<-c("month",c(1:31))
    d[[j]]$river<-river
    d[[j]]$site<-site
    d[[j]]$year<-x[j]
  }
  precip[[k]]<-do.call(rbind,d)
}

precip<-do.call(rbind,precip)

write.csv(precip,"/Volumes/HD-ADU3/GIS/Projects/mizukoku/output/CSV/precipitation.csv",fileEncoding="UTF8",row.names=FALSE)

precip<-read.csv("/Volumes/HD-ADU3/GIS/Projects/mizukoku/output/CSV/precipitation.csv",header=TRUE,encoding="UTF8")
precip$NAs<-apply(precip[,2:32],1,function(x)length(x[is.na(x)]))
precip$total<-apply(precip[,2:32],1,sum,na.rm=TRUE)
precip$Ndate<-c(31,28,31,30,31,30,31,31,30,31,30,31)
precip$total<-ifelse((precip$Ndate-(31-precip$NAs))>5,NA,precip$total) #5日以上の欠測がある月は除く
precip$month<-as.numeric(gsub("月","",precip$month))
precip$river<-factor(precip$river,
                     levels=c("千代川","天神川","日野川","斐伊川","江の川","高津川","吉井川","旭川","高梁川","芦田川","太田川","小瀬川","佐波川",
                                           "吉野川","土器川","重信川","肱川","那賀川","物部川","仁淀川","渡川"),
                     labels=c("Chiyo","Tenjin","Hino","Hii","Gono","Takatsu","Yoshii","Asahi","Takahari","Asida","Ohota","Oze","Saba",
                              "Yoshino","Doki","Shigenobu","Hiji","Naka_Shikoku","Monobe","Niyodo","Shimanto"),ordered=TRUE)

precip2<-data.frame(
  river=rep(levels(precip$river),each=12),
  month=rep(c(1:12),length(levels(precip$river))),
  mean=as.vector(tapply(precip$total,list(precip$month,precip$river),mean,na.rm=TRUE)),
  sd=as.vector(tapply(precip$total,list(precip$month,precip$river),sd,na.rm=TRUE))
)
precip2$river<-factor(precip2$river,
                     levels=c("Chiyo","Tenjin","Hino","Hii","Gono","Takatsu","Yoshii","Asahi","Takahari","Asida","Ohota","Oze","Saba",
                              "Yoshino","Doki","Shigenobu","Hiji","Naka_Shikoku","Monobe","Niyodo","Shimanto"),ordered=TRUE)

precip_long = precip %>% pivot_longer(c(-year,-month,-site,-river,-NAs,-total,-Ndate), names_to = "date", values_to = "precip")
precip_long$date<-as.numeric(gsub("X","",precip_long$date))
precip_long$precip<-as.numeric(precip_long$precip)

paste0(round(apply(tapply(precip_long$precip,list(precip_long$river,precip_long$site,precip_long$year),sum,na.rm=TRUE),1,mean,na.rm=TRUE),1),
       " ± ",
       round(apply(tapply(precip_long$precip,list(precip_long$river,precip_long$site,precip_long$year),sum,na.rm=TRUE),1,sd,na.rm=TRUE),1))

#
g<-ggplot(data=precip2,aes(x=month,y=mean))+
  geom_bar(stat = "identity",position = position_dodge(width = 0.0),fill="#C0C0C0")+
  geom_errorbar(aes(ymax=mean+sd,ymin=mean-sd),position=position_dodge(0.0),width=0.5,size=0.2)+
  facet_wrap(~river,ncol=4,scales="free_y")+
  theme_classic() + 
  theme(aspect.ratio=0.5)
g
ggsave("/Volumes/HD-ADU3/GIS/Projects/mizukoku/output/PDF/precipitation.pdf",g)


