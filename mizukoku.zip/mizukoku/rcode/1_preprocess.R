setwd("dir/mizukoku")

library(readxl)
library(rlang)
library(sf)
library(ggplot2)
library(stringi)

# Downloaded files of csv and shp files with zip compression were decompressed into "dir/rawdata/mizukoku_csv" and "dir/rawdata/mizukoku_shp", respectively.
# lzh files were decomposed using "preprocess.py".
# Typo in "底生_九州.xlsx" using a double quotation for a consonant mark in the taxonomic name "グマガトビケラ" was manually corrected.
# ID of sampling sites in each watershed contains several irregular input rules, and is not uniquely determined. Therefore, number of sampling sites within each watershed was manually and visually counted based on location data that were pointed on a map.

#Pairing "調査管理番号" (data ID) and "緯度経度" (longitude and latitude)
path1<-paste(getwd(),"/rawdata/mizukoku_shp",sep="")
list1<-list()
p<-0
for(i in c(1:length(dir(path1)))){
  path2<-paste(path1,"/",dir(path1)[i],"/shapefiles",sep="")
  for(j in c(1:length(dir(path2)))){
    path3<-paste(path2,"/",dir(path2)[j],sep="")
    if(length(dir(path3,pattern="chiku.shp"))>=1){
      path4<-paste(path3,"/",dir(path3,pattern="chiku.shp")[1],sep="") # first one file was used
      d<-st_read(path4,options="ENCODING=SJIS")
      d<-d[,c("調査管理番","調査年度","geometry")]
      d<-d[complete.cases(d$調査管理番),] # Remove files without "調査管理番"
      if(nrow(d)>=1){
        p<-p+1
        list1[[p]]<-d[1,] # Use first row to reduce file size
      }
    }
  }}

data01<-do.call(rbind,list1)
data01$w_name<-NA
data01$r_name<-NA

#merge mesh data of watersheds (https://nlftp.mlit.go.jp/ksj/gml/datalist/KsjTmplt-W07.html)
#Downloaded zip files were decompressed into "dir/rawdata/GIS_data/Watersheds/mesh"
path1<-paste(getwd(),"/rawdata/GIS_data/Watersheds/mesh",sep="")

st_crs(data01)=4612 #JGD2000
for(i in c(1:length(dir(path1)))){
  path2<-paste(path1,"/",dir(path1)[i],sep="")
  if(length(dir(path2,pattern=".shp"))>=1){
    path3<-paste(path2,"/",dir(path2,pattern=".shp")[1],sep="") # first one file was used
    d1<-st_read(path3,options="ENCODING=SJIS")
    d1<-d1[complete.cases(d1$W07_004),c("W07_004","W07_005","geometry")]
    d1<-d1[!d1$W07_004=="unknown",c("W07_004","W07_005","geometry")]
    d1<-d1[!d1$W07_004=="名称不明",c("W07_004","W07_005","geometry")]
    if(nrow(d1)>=1){
      st_crs(d1)=4612 #JGD2000
      d2<-st_intersects(st_buffer(data01,dist=100),d1) #Spatial mismatches ≤100 m were ignored
      use<-sapply(d2,length)>=1
      data01$w_name[use]<-sapply(d1$"W07_004",unique)[sapply(d2,function(x)unique(x)[1])][use]
      data01$r_name[use]<-sapply(d1$"W07_005",unique)[sapply(d2,function(x)unique(x)[1])][use]
    }
  }
}

data01$longitude<-sapply(strsplit(as.character(data01$geometry),", "),function(x)ifelse(complete.cases(x[1]),as.numeric(sub("c\\(","",x[1])),NA))
data01$latitude<-sapply(strsplit(as.character(data01$geometry),", "),function(x)ifelse(complete.cases(x[2]),as.numeric(sub("\\)","",x[2])),NA))

data01<-as.data.frame(data01)[,c("調査管理番","調査年度","w_name","r_name","longitude","latitude")]
data01$調査年度[data01$調査年度=="19950905"]<-1995
data01$調査年度[data01$調査年度=="1999〜2000"]<-1999

write.csv(data01,paste(getwd(),"/output/CSV/data_id.csv",sep=""),fileEncoding="SJIS",row.names=FALSE)
data01<-read.csv(file(paste(getwd(),"/output/CSV/data_id.csv",sep=""),encoding="SJIS"),header=TRUE,sep=",")  #

path1<-paste(getwd(),"/rawdata/mizukoku_csv",sep="")
path2a<-paste(path1,dir(path1,pattern="魚類"),sep="/")
path2b<-paste(path1,dir(path1,pattern="底生"),sep="/")

data02<-list()
p<-0
for(i in 1:length(path2a)){
  p<-p+1
  data02[[p]]<-read_excel(path2a[i],na="")[,c("調査管理番号","種コード","種名","個体数","水系","河川名","季節")]
  data02[[p]]$地区番号<-NA
  data02[[p]]$category<-"fish"
}
for(i in 1:length(path2b)){
  p<-p+1
  if(length(grep("中国",path2b[i]))==1 | length(grep("四国",path2b[i]))==1){
    data02[[p]]<-read_excel(path2b[i],na="")[,c("調査管理番号","種コード","種名","個体数","水系","河川名","季節","地区番号_修正_1km以内は集約")]
    names(data02[[p]])<-c("調査管理番号","種コード","種名","個体数","水系","河川名","季節","地区番号")}
  else{
    data02[[p]]<-read_excel(path2b[i],na="")[,c("調査管理番号","種コード","種名","個体数","水系","河川名","季節")]
    data02[[p]]$地区番号<-NA
  }
  data02[[p]]$category<-"benthos"
}
data02<-do.call(rbind,data02)

# Merge data01 and data02 by "調査管理番号"
names(data01)[names(data01)=="調査管理番"]<-"調査管理番号"
data02<-merge(data02,data01,by="調査管理番号",all.x=TRUE)

table(data02$調査年度)
# correct years
data02$調査年度[!is.element(data02$調査年度,c(1990:2030))]<-as.numeric(substr(data02$調査管理番号[!is.element(data02$調査年度,c(1990:2030))],2,5))
# Compensate the missing values of years
data02$調査年度[is.na(data02$調査年度)]<-as.numeric(substr(data02$調査管理番号,2,5)[is.na(data02$調査年度)])
data02$調査年度<-as.numeric(data02$調査年度)

# debag
data02$w_name[which(!data02$"水系"==data02$"w_name" | is.na(data02$"w_name"))]<-data02$"水系"[which(!data02$"水系"==data02$"w_name" | is.na(data02$"w_name"))]
data02$種名<-stri_trans_general(data02$種名,'NFKC') # Unicode normalization
data02$地区番号<-stri_trans_general(data02$地区番号,'NFKC') # Unicode normalization
#table(complete.cases(data02$種コード))
#data02<-data02[complete.cases(data02$種コード),] # Remove data without taxon code
#data02<-data02[data02$種コード>=1000,] # Remove irregular taxon code
data02<-data02[data02$個体数>=1,] # Remove zero count of individuals
#data02<-data02[complete.cases(data02$個体数),] # Remove data without number of individuals

write.csv(data02,paste(getwd(),"/output/CSV/data_obs.csv",sep=""),fileEncoding="SJIS",row.names=FALSE)

