library(sf)
library(maptools)
library(rgdal)
library(ggplot2)

data01<-read_sf("dir/mizukoku/output/SHP/Geol.shp")
data02<-read_sf("dir/mizukoku/output/SHP/Watershed.shp")

data01$group_en2<-NA
data01$group_en2[data01$group_en=="Sedimentary rocks"]<-"Sedimentary rocks"
data01$group_en2[data01$group_en=="Other"]<-"Other"
data01$group_en2[data01$group_en=="Accretionary complexes"]<-"Accretionary complexes"
data01$group_en2[data01$group_en=="Metamorphic rocks"]<-"Metamorphic rocks"
data01$group_en2[data01$group_en=="Igneous rocks"]<-"Volcanic rocks"
data01$group_en2[grep("堆積物",data01$lithol_ja)]<-"Sediments"
data01$group_en2[grep("花崗",data01$lithol_ja)]<-"Plutonic rocks"
data01$group_en2[grep("超苦鉄質岩類",data01$lithol_ja)]<-"Plutonic rocks"
data01$group_en2[grep("斑れい岩",data01$lithol_ja)]<-"Plutonic rocks"
data01$group_en2[grep("閃緑岩",data01$lithol_ja)]<-"Plutonic rocks"

st_write(data01,paste("/Volumes/HD-ADU3/GIS/Projects/mizukoku/output/SHP/Geol2.shp",sep=""),driver="ESRI Shapefile",append=FALSE,layer_options="ENCODING=SJIS")

data01<-read_sf("/Volumes/HD-ADU3/GIS/Projects/mizukoku/output/SHP/Geol2.shp")
data02<-read_sf("/Volumes/HD-ADU3/GIS/Projects/mizukoku/output/SHP/Watershed2.shp")

t<-tapply(data01$Area,list(data01$group_en2,data01$W12_002),sum,na.rm=TRUE)/1000000
t<-round(t(t)/apply(t,2,sum,na.rm=TRUE),2)
rownames(t)<-c("Chiyo","Tenjin","Hino","Hii","Gono","Takatsu","Yoshii","Asahi","Takahari","Asida","Ohota","Oze","Saba",
               "Yoshino","Naka_Shikoku","Doki","Shigenobu","Hiji","Monobe","Niyodo","Shimanto")

