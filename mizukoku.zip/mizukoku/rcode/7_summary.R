setwd("dir/mizukoku")

library(rlang)
library(ggplot2)
library(stringi)
library(vegan)
library(car)
library(ggVennDiagram)

# census data
data01<-read.csv(file(paste(getwd(),"/output/CSV/data_obs_compile.csv",sep=""),encoding="SJIS"),header=TRUE,sep=",")

# ecological traits of aquatic insects
data02<-read.csv(file(paste(getwd(),"/rawdata/data_taxon.csv",sep=""),encoding="UTF8"),header=TRUE,sep=",")
data02<-data02[is.element(data02$Taxon,unique(data01$Taxon)),]

# environmental characteristics in each watershed
data03<-read.csv(file(paste(getwd(),"/output/CSV/watershed.csv",sep=""),encoding="UTF8"),header=TRUE,sep=",")


data01<-merge(data01[,c("調査管理番号","category","調査年度","w_name","r_name","地区番号","longitude","latitude","Taxon")],data02,by="Taxon",all.x=TRUE)

# remove data in tributaries
data01<-data01[!data01$w_name=="余市川",]
data01<-data01[!data01$w_name=="犀川",]
data01<-data01[!data01$w_name=="",]

# distinguish Arakawa in Hokuriku and Kanto regions
#hist(data01$latitude[data01$w_name=="荒川"])
#hist(data01$longitude[data01$w_name=="荒川"])
data01$w_name[data01$w_name=="荒川"]<-ifelse(data01$latitude[data01$w_name=="荒川"]>37,"荒川_北陸","荒川_関東")

t<-table(data01$w_name)
length(t) #109水系

# name of watersheds (there are two "Nakagawa" with different Japanese caharacter "那珂川" and "那賀川", and distinguished as "Naka_Kanto" and "Naka_Shikoku")
use<-c("天塩川","渚滑川","湧別川","常呂川","網走川","留萌川","石狩川","尻別川","後志利別川","鵡川","沙流川","釧路川","十勝川",
       "岩木川","高瀬川","馬淵川","北上川","鳴瀬川","名取川","阿武隈川","米代川","雄物川","子吉川","最上川","赤川",
       "久慈川","那珂川","利根川","荒川_関東","多摩川","鶴見川","相模川","富士川",
       "荒川_北陸","阿賀野川","信濃川","関川","姫川","黒部川","常願寺川","神通川","庄川","小矢部川","手取川","梯川",
       "狩野川","安倍川","大井川","菊川","天竜川","豊川","矢作川","庄内川","木曽川","鈴鹿川","雲出川","櫛田川","宮川",
       "九頭竜川","北川","由良川","淀川","大和川","円山川","加古川","揖保川","紀の川","新宮川",
       "千代川","天神川","日野川","斐伊川","江の川","高津川","吉井川","旭川","高梁川","芦田川","太田川","小瀬川","佐波川",
       "吉野川","土器川","重信川","肱川","那賀川","物部川","仁淀川","渡川",
       "遠賀川","山国川","筑後川","矢部川","松浦川","六角川","嘉瀬川","本明川","菊池川","白川","緑川",
       "球磨川","大分川","大野川","番匠川","五ヶ瀬川","小丸川","大淀川","川内川","肝属川")
lab<-c("Teshio","Shokotsu","Yubetsu","Tokoro","Abashiri","Rumoe","Ishikari","Shiribetsu","Shiribetsutoshibetsu","Mu","Saru","Kushiro","Tokachi",
       "Iwaki","Takase","Mabechi","Kitakami","Naruse","Natori","Abukuma","Yoneshiro","Omono","Koyoshi","Mogami","Aka",
       "Kuji","Naka_Kanto","Tone","Ara_Kanto","Tama","Tsurumi","Sagami","Fuji",
       "Ara_Hokuriku","Agano","Shinano","Seki","Hime","Kurobe","Johganji","Jintsu","Sho","Oyabe","Tedori","Kakehashi",
       "Kano","Abe","Ohi","Kiku","Tenryu","Toyo","Yahagi","Shonai","Kiso","Suzuka","Kumozu","Kushida","Miya",
       "Kuzuryu","Kita","Yura","Yodo","Yamato","Maruyama","Kako","Ibo","Kino","Kumano",
       "Chiyo","Tenjin","Hino","Hii","Gono","Takatsu","Yoshii","Asahi","Takahari","Asida","Ohota","Oze","Saba",
       "Yoshino","Doki","Shigenobu","Hiji","Naka_Shikoku","Monobe","Niyodo","Shimanto",
       "Onga","Yamakuni","Chikugo","Yabe","Matsuura","Rokkaku","Kase","Honmyo","Kikuchi","Shira","Midori",
       "Kuma","Ohita","Ohno","Banjyo","Gokase","Omaru","Ohyodo","Sendai","Kimotsuki")
lv_region<-c("Hokkaido","Tohoku","Kanto","Hokuriku","Chubu","Kinki","Chugoku","Shikoku","Kyusyu")
region<-c(rep("Hokkaido",13),rep("Tohoku",12),rep("Kanto",8),rep("Hokuriku",12),rep("Chubu",13),
        rep("Kinki",10),rep("Chugoku",13),rep("Shikoku",8),rep("Kyusyu",20))

# relabeling the name of watersheds
data01$w_name<-factor(as.character(data01$w_name),levels=use,labels=lab,ordered=TRUE)

# sampling periods (5 years in a round)
data01$period<-as.numeric(cut(data01$調査年度,br=seq(1991,2021,5),include.lowest=TRUE,right=FALSE,labels=c(1:6)))
table(data01$w_name,data01$period)
# remove duplication
data01<-data01[!duplicated(paste(data01$Taxon,data01$w_name,data01$period)),]

# data in Chugoku and Shikoku regions
use<-c("Chiyo","Tenjin","Hino","Hii","Gono","Takatsu","Yoshii","Asahi","Takahari","Asida","Ohota","Oze","Saba",
       "Yoshino","Doki","Shigenobu","Hiji","Naka_Shikoku","Monobe","Niyodo","Shimanto")
region<-c(rep("Chugoku",13),rep("Shikoku",8))
#basin<-c(rep("Sanin",6),rep("Sanyo",7),rep("Setouchi",4),rep("Taiheiyo",4))
d01<-data01[is.element(data01$w_name,use),]
d03<-data03[is.element(data03$River,use),]
d01$w_name<-factor(d01$w_name,levels=use,ordered=TRUE)
d01<-d01[d01$category=="benthos",]
d02<-data02[data02$Category=="benthos",]
#d01<-d01[d01$category=="fish",]
#d02<-data02[data02$Category=="fish",]
d02<-d02[is.element(d02$Taxon,d01$Taxon),]
d03<-data03[is.element(data03$River,use),]
d03$w_name<-factor(d03$River,levels=use,ordered=TRUE)
d03<-d03[order(d03$w_name),]
d03$Drought<-ifelse(is.element(d03$w_name,c("Yoshii","Asahi","Takahari","Asida","Doki","Shigenobu")),1,0)
d03$Forest_prop<-d03$Forest/d03$Watershed_area

d01$region<-factor(d01$w_name,labels=region,ordered=TRUE)
d01$Drought<-ifelse(is.element(d01$w_name,c("Yoshii","Asahi","Takahari","Asida","Doki","Shigenobu")),1,0)

d01$地区番号[d01$地区番号=="NA"]<-NA
d01<-d01[complete.cases(d01$地区番号),]

nrow(d01)

length(unique(d01$Order))
length(unique(d01$Family))
length(unique(d01$Genus))
length(unique(d01$Taxon))

# number of sampling sites in each river
tapply(d01$地区番号,d01$w_name,unique)

d0<-data.frame(tapply(d01$地区番号,d01$w_name,function(x)length(unique(x))))
names(d0)<-c("N_site")
d0$w_name<-rownames(d0)
paste0(round(tapply(d0$N_site,region,mean),1)," ± ",round(tapply(d0$N_site,region,sd),1))
d0
d01<-merge(d01,d0,by="w_name",all.x=TRUE)
d03<-merge(d03,d0,by="w_name",all.x=TRUE)

# number of aquatic insect taxa in each river
t<-tapply(d01$Taxon,d01$w_name,function(x)length(unique(x)))
Drought<-ifelse(is.element(names(t),c("Yoshii","Asahi","Takahari","Asida","Doki","Shigenobu")),1,0)
t

paste0(round(tapply(t,region,mean),1)," ± ",round(tapply(t,region,sd),1))
paste0(round(tapply(t[region=="Chugoku"],Drought[region=="Chugoku"],mean),1)," ± ",round(tapply(t[region=="Chugoku"],Drought[region=="Chugoku"],sd),1))
paste0(round(tapply(t[region=="Shikoku"],Drought[region=="Shikoku"],mean),1)," ± ",round(tapply(t[region=="Shikoku"],Drought[region=="Shikoku"],sd),1))

anova(lm(t~tapply(d01$N_site,d01$w_name,unique)+region+Drought))

t<-table(d01$w_name,d01$period)
t0<-t(apply(t,1,function(x){x<-x[x>0];paste(round(mean(x),1)," ± ",round(sd(x),1)," (",length(x),")",sep="")}))
write.csv(t0,paste0(getwd(),"/output/CSV/table2.csv"),fileEncoding="UTF8")

# Venn diagram
t1<-table(d01$Taxon,d01$region)
t2<-table(d01$Taxon,d01$Drought)
t3<-list(
  Chugoku=rownames(t1)[t1[,1]>0],
  Shikoku=rownames(t1)[t1[,2]>0],
  Drought=rownames(t1)[t2[,2]>0]
  )
ggVennDiagram(t3)

# NMDS
t01<-table(d01$Taxon,d01$w_name)
t01<-apply(t01,1,function(x)ifelse(x>0,1,0))

nmds<-metaMDS(t01,k=3,distance="jaccard")

sp01<-as.data.frame(nmds$species)
si01<-as.data.frame(nmds$points)
hist(sp01$MDS1)
hist(sp01$MDS2)
hist(sp01$MDS3)

or01<-order(d02$Taxon)
sp01$size<-d02$Bodysize[or01]
sp01$size<-factor(sp01$size,labels=c("<1.0","≥1.0","≥1.0"),ordered=TRUE)
sp01$voltinism<-"≥1"
sp01$voltinism[d02$Voltinism_Multivoltine[or01]==1]<-"<1"
sp01$voltinism<-factor(sp01$voltinism,levels=c("<1","≥1"),ordered=TRUE)
sp01$reproduction<-"Aquatic"
sp01$reproduction[d02$Reproduction_terrestrial[or01]==1]<-"Terrestrial"
sp01$reproduction<-factor(sp01$reproduction,levels=c("Terrestrial","Aquatic"),ordered=TRUE)
sp01$respiration<-"Aquatic"
sp01$respiration[d02$Respiration_Aerial[or01]==1]<-"Aerial"
sp01$respiration<-factor(sp01$respiration,levels=c("Aerial","Aquatic"),ordered=TRUE)
sp01$locomotion<-"Riverbed"
sp01$locomotion[d02$Locomotion_Interstitial[or01]==1]<-"Interstitial"
sp01$locomotion<-factor(sp01$locomotion,levels=c("Interstitial","Riverbed"),ordered=TRUE)

si01$site<-rownames(si01)
si01$region<-c(rep("Chugoku",13),rep("Shikoku",8))
si01$Drought<-ifelse(is.element(si01$site,c("Yoshii","Asahi","Takahari","Asida","Doki","Shigenobu")),1,0)

#Permutation test
ef<-envfit(nmds,d03[order(d03$w_name),c("Drought","N_site","Watershed_area","Elv","Slope","Forest_prop")],choices=c(1:3),permu=9999)
ef
ef01<-as.data.frame(ef$vectors$arrows)
ef01$type<-rownames(ef01)
ef01<-ef01[ef$vectors$pvals<=0.05,]

#Plot
s<-2
g1<-ggplot(data=si01) +
  geom_vline(xintercept=0,colour="#A9A9A9") +
  geom_hline(yintercept=0,colour="#A9A9A9") +
  geom_point(aes(x=MDS1,y=MDS2,shape=paste0(region,Drought),color=paste0(region,Drought)),size=8) +
  geom_segment(data=ef01,aes(x=0,y=0,xend=NMDS1/s,yend=NMDS2/s),arrow=arrow(length=unit(0.5,"cm")),colour="#A9A9A9") +
  geom_text(aes(x=MDS1,y=MDS2+0.02,label=site)) +
  geom_text(data=ef01,aes(x=NMDS1/s,y=NMDS2/s,label=type),colour="#A9A9A9") +
  scale_shape_manual(values=c(16,15,18,17)) +
  scale_color_manual(values=c("#8FBC8F","#FFA07A","#4169E1","#DC143C")) +
  #xlim(c(min(sp01$MDS1),max(sp01$MDS1))) +
  #ylim(c(min(sp01$MDS2),max(sp01$MDS2))) +
  theme_classic() + 
  theme(aspect.ratio=1,text=element_text(size=20),legend.position="")
g1
ggsave(paste(getwd(),"/output/PDF/site_1.pdf",sep=""),g1)

g2<-ggplot(data=si01) +
  geom_vline(xintercept=0,colour="#A9A9A9") +
  geom_hline(yintercept=0,colour="#A9A9A9") +
  geom_point(aes(x=MDS1,y=MDS3,shape=paste0(region,Drought),color=paste0(region,Drought)),size=8) +
  geom_segment(data=ef01,aes(x=0,y=0,xend=NMDS1/s,yend=NMDS3/s),arrow=arrow(length=unit(0.5,"cm")),colour="#A9A9A9") +
  geom_text(aes(x=MDS1,y=MDS3+0.02,label=site)) +
  geom_text(data=ef01,aes(x=NMDS1/s,y=NMDS3/s,label=type),colour="#A9A9A9") +
  scale_shape_manual(values=c(16,15,18,17)) +
  scale_color_manual(values=c("#8FBC8F","#FFA07A","#4169E1","#DC143C")) +
  theme_classic() + 
  theme(aspect.ratio=1,text=element_text(size=20),legend.position="")
g2
ggsave(paste(getwd(),"/output/PDF/site_2.pdf",sep=""),g2)

#Voltinism
sp02<-sp01[which((sp01$voltinism=="<1" & abs(sp01$MDS1)>0.4) | (sp01$voltinism=="<1" & abs(sp01$MDS2)>0.4)),]
sp02$species<-row.names(sp02)
g<-ggplot() +
  geom_vline(xintercept=0,colour="#A9A9A9") +
  geom_hline(yintercept=0,colour="#A9A9A9") +
  geom_point(data=sp01,aes(x=MDS1,y=MDS2,color=voltinism,size=voltinism)) +
  geom_text(data=sp02,aes(x=MDS1,y=MDS2+0.02,label=species)) +
  scale_size_manual(values=c(6,2,2)) +
  scale_color_manual(values=c("#FFA07A","#4169E1","#C0C0C0")) +
  theme_classic() + 
  theme(aspect.ratio=1,text=element_text(size=20),legend.position="bottom")
g
ggsave(paste(getwd(),"/output/PDF/voltinism.pdf",sep=""),g)

#Respiration
sp02<-sp01[which((sp01$respiration=="Aerial" & abs(sp01$MDS1)>0.4) | (sp01$respiration=="Aerial" & abs(sp01$MDS2)>0.4)),]
sp02$species<-row.names(sp02)
g<-ggplot() +
  geom_vline(xintercept=0,colour="#A9A9A9") +
  geom_hline(yintercept=0,colour="#A9A9A9") +
  geom_point(data=sp01,aes(x=MDS1,y=MDS2,color=respiration,size=respiration)) +
  geom_text(data=sp02,aes(x=MDS1,y=MDS2+0.02,label=species)) +
  scale_size_manual(values=c(6,2,2)) +
  scale_color_manual(values=c("#FFA07A","#4169E1","#C0C0C0")) +
  theme_classic() + 
  theme(aspect.ratio=1,text=element_text(size=20),legend.position="bottom")
g
ggsave(paste(getwd(),"/output/PDF/respiration.pdf",sep=""),g)

# Data set for GLM
d<-as.data.frame(table(d01$w_name,d01$Taxon)) # number of occurrence of each taxon in each river
colnames(d)<-c("w_name","Taxon","Presence")

p<-data.frame(N=tapply(d01$period,d01$w_name,function(x)length(unique(x)))) # number of sampling periods in each river
p$w_name<-rownames(p)

o<-table(paste(d01$w_name,d01$period),d01$Taxon)
o<-apply(o,1,function(x)ifelse(x,1,0))
o<-as.data.frame(apply(o,1,sum)/length(unique(paste(d01$w_name,d01$period)))) # Using the log-odds of the occurrence probability of each taxa pooling rivers and sampling periods as the offset term, the model tests the deviation of the distribution probability at each sampling site from the average of all sampling sites.
colnames(o)<-"Prop"
o$Taxon<-rownames(o)

d<-merge(d,d02[,c("Taxon","Bodysize","Voltinism_Multivoltine","Reproduction_terrestrial","Respiration_Aerial","Locomotion_Interstitial")],by="Taxon",all.x=TRUE)
d<-merge(d,o,by="Taxon",all.x=TRUE)
d<-merge(d,p,by="w_name",all.x=TRUE)
d<-merge(d,d03,by="w_name",all.x=TRUE)
d<-d[d$Prop<1,] # Remove taxa observed in the all observations

# multicollinearity
lm01<-glm(cbind(Presence,N-Presence)~
            Voltinism_Multivoltine+
            Reproduction_terrestrial+
            Respiration_Aerial+
            Locomotion_Interstitial+
            Drought+
            N_site+
            Watershed_area+
            #Slope+
            Elv+
            Forest_prop+
            offset(log(Prop/(1-Prop))),data=d,family=binomial(link="logit"))
vif(lm01) #VIF<5

#GLM
glm01<-glm(cbind(Presence,N-Presence)~ # Number of occurrence during the N-times sampling periods.
             (Voltinism_Multivoltine*Drought)+
             (Reproduction_terrestrial*Drought)+
             (Respiration_Aerial*Drought)+
             (Locomotion_Interstitial*Drought)+
             Watershed_area+
             Elv+
             Forest_prop+
             N_site+
             offset(log(Prop/(1-Prop))),
           data=d,family=binomial(link="logit"))
summary(glm01)

newdata0<-data.frame(
  X=c(1,1,0,0),
  Bodysize=2,
  Voltinism_Multivoltine=c(1,1,0,0),
  Reproduction_terrestrial=0,
  Respiration_Aerial=0,
  Locomotion_Interstitial=0,
  Drought=c(1,0,1,0),
  Watershed_area=mean(d$Watershed_area),
  Elv=mean(d$Elv),
  Forest_prop=mean(d$Forest_prop),
  N_site=mean(d$N_site),
  Prop=0.5)

pr_Voltinism<-predict(glm01,
                      newdata=newdata0,
                      type="response",se.fit=TRUE)
newdata0$fit<-pr_Voltinism$fit
newdata0$se.fit<-pr_Voltinism$se.fit
newdata0$type<-"Voltinism"
newdata00<-newdata0

newdata0<-data.frame(
  X=c(1,1,0,0),
  Bodysize=2,
  Voltinism_Multivoltine=0,
  Reproduction_terrestrial=0,
  Respiration_Aerial=c(1,1,0,0),
  Locomotion_Interstitial=0,
  Drought=c(1,0,1,0),
  Watershed_area=mean(d$Watershed_area),
  Elv=mean(d$Elv),
  Forest_prop=mean(d$Forest_prop),
  N_site=mean(d$N_site),
  Prop=0.5)

pr_Voltinism<-predict(glm01,
                      newdata=newdata0,
                      type="response",se.fit=TRUE)
newdata0$fit<-pr_Voltinism$fit
newdata0$se.fit<-pr_Voltinism$se.fit
newdata0$type<-"Aerial respiration"
newdata00<-rbind(newdata00,newdata0)

g<-ggplot(data=newdata00) +
  #geom_jitter(data=d,aes(x=Locomotion_Interstitial,y=Presence/N,color=Drought),size=1,alpha=0.5) +
  geom_errorbar(aes(x=X+Drought*0.1,ymin=fit-se.fit*1.96,ymax=fit+se.fit*1.96),width=0.1) +
  geom_line(aes(x=X+Drought*0.1,y=fit,color=as.factor(Drought))) +
  geom_point(aes(x=X+Drought*0.1,y=fit,color=as.factor(Drought)),size=3) +
  facet_wrap(~type) +
  scale_x_continuous(limits=c(-0.2,1.2),breaks=seq(0,1)) +
  labs(x="",y="",color="") + 
  theme_classic() + 
  theme(aspect.ratio=1,text=element_text(size=16),legend.position="bottom")
g
ggsave(paste(getwd(),"/output/PDF/glm_result.pdf",sep=""),g)
