setwd("dir/mizukoku/rawdata/download/discharge")

library("rvest")
library(tidyr)
library(tidyverse)
library(ggplot2)
library(scales)

id01<-c(
  308011288805001, #重信川
  308021288806004, #肱川
  308031288809008, #四万十川
  308041288808020, #仁淀川
  308051288808020, #物部川
  308061288803001, #那賀川
  308071288801007, #吉野川
  308081288804001, #土器川
  307011287701050, #千代川
  307021287702030, #天神川
  307031287703040, #日野川
  307041287705040, #斐伊川
  307051287707080, #江の川
  307061287707040, #高津川
  307071287715050, #佐波川
  307081287712020, #小瀬川
  307091287712200, #太田川
  307101287710060, #芦田川
  307111287708170, #高梁川
  307121287708040, #旭川
  307131287708090 #吉井川
)

f<-function(x){
  url <- paste0("http://www1.river.go.jp/cgi-bin/SiteInfo.exe?ID=",x)
  html<-read_html(url)
  tb<-html_table(html)
  ifelse(length(tb)>0,x,NA)
}

list_id<-data.frame(id01)

x<-c(2002:2022)
discharge<-list()
for(k in 1:nrow(list_id)){
  html_list<-list()
  dat_url<-list()
  for(i in 1:length(x)){
    html_list[[i]]<-read_html(paste("http://www1.river.go.jp/cgi-bin/DspWaterData.exe?KIND=7&ID=",list_id[k,],"&BGNDATE=",x[i],"0131&ENDDATE=",x[i],"1231&KAWABOU=NO",sep=""))
    dat_url[i] = html_list[[i]] %>%
      html_nodes("a") %>%   ## find all links
      html_attr("href") %>% ## pull out url
      str_subset("\\.dat")  ## pull out dat links
    download.file(paste("http://www1.river.go.jp",dat_url[i],sep=""),destfile=sub("dat","txt",sub("/dat/dload/download/","",dat_url[i])))
  }
  d<-list()
  for(j in 1:length(x)){
    a<-readLines(file(paste(getwd(),sub("dat","txt",sub("/dat/dload/download/","",dat_url[j])),sep="/"),encoding="SJIS"))
    river<-strsplit(a[2],",")[[1]][2]
    site<-strsplit(a[4],",")[[1]][2]
    a<-a[c(12:23)]
    for(i in 1:length(a)){a[i]<-gsub(" ","",a[i])}
    for(i in 1:length(a)){a[i]<-gsub("\\$","",a[i])}
    for(i in 1:length(a)){a[i]<-gsub("-","",a[i])}
    for(i in 1:length(a)){a[i]<-gsub(",,",",",a[i])}
    for(i in 1:length(a)){a[i]<-gsub("9999.00","",a[i])}
    for(i in 1:length(a)){a[i]<-gsub("9999.0","",a[i])}
    for(i in 1:length(a)){a[i]<-gsub("9999.99","",a[i])}
    b<-list()
    for(i in 1:length(a)){b[i]<-strsplit(a[i],",");if(length(b[i])<32)b[[i]]<-c(b[[i]],rep("",32-length(b[[i]])))}
    d[[j]]<-as.data.frame(do.call(rbind,b))
    colnames(d[[j]])<-c("month",c(1:31))
    d[[j]]$river<-river
    d[[j]]$site<-site
    d[[j]]$year<-x[j]
  }
  discharge[[k]]<-do.call(rbind,d)
}

discharge<-do.call(rbind,discharge)

write.csv(discharge,"/Volumes/HD-ADU3/GIS/Projects/mizukoku/output/CSV/discharge.csv",fileEncoding="UTF8",row.names=FALSE)

discharge<-read.csv("/Volumes/HD-ADU3/GIS/Projects/mizukoku/output/CSV/discharge.csv",header=TRUE,encoding="UTF8")
discharge$NAs<-apply(discharge[,2:32],1,function(x)length(x[is.na(x)]))
discharge$total<-apply(discharge[,2:32],1,sum,na.rm=TRUE)
discharge$Ndate<-c(31,28,31,30,31,30,31,31,30,31,30,31)
#discharge$total<-ifelse((discharge$Ndate-(31-discharge$NAs))>5,NA,discharge$total) #5日以上の欠測がある月は除く
discharge$month<-as.numeric(gsub("月","",discharge$month))
discharge$river<-factor(discharge$river,
                     levels=c("千代川","天神川","日野川","斐伊川","江の川","高津川","吉井川","旭川","高梁川","芦田川","太田川","小瀬川","佐波川",
                                           "吉野川","土器川","重信川","肱川","那賀川","物部川","仁淀川","渡川"),
                     labels=c("Chiyo","Tenjin","Hino","Hii","Gono","Takatsu","Yoshii","Asahi","Takahari","Asida","Ohota","Oze","Saba",
                              "Yoshino","Doki","Shigenobu","Hiji","Naka_Shikoku","Monobe","Niyodo","Shimanto"),ordered=TRUE)

discharge_long = discharge %>% pivot_longer(c(-year,-month,-site,-river,-NAs,-total,-Ndate), names_to = "date", values_to = "discharge")
discharge_long$date<-as.numeric(gsub("X","",discharge_long$date))
discharge_long$date2<-paste(discharge_long$year,formatC(discharge_long$month,width=2,flag="0"),formatC(discharge_long$date,width=2,flag="0"),sep="-")
discharge_long$date2<-as.Date(discharge_long$date2)
discharge_long$discharge<-as.numeric(discharge_long$discharge)
discharge_long$area<-factor(discharge_long$river,levels=levels(discharge_long$river),labels=c(rep("Chugoku",13),rep("Shikoku",8)))
discharge_long$drought<-ifelse(is.element(discharge_long$river,c("Yoshii","Asahi","Takahari","Asida","Doki","Shigenobu")),1,0)
discharge_long$river<-factor(discharge_long$river,levels=c("Chiyo","Tenjin","Hino","Hii","Gono","Takatsu","Ohota","Oze","Saba","Yoshii","Asahi","Takahari","Asida",
                                                      "Doki","Shigenobu","Yoshino","Hiji","Naka_Shikoku","Monobe","Niyodo","Shimanto"),ordered=TRUE)

discharge_long$discharge[discharge_long$discharge==0 & discharge_long$river=="Tenjin"]<-NA
discharge_long$discharge[discharge_long$discharge==0 & discharge_long$river=="Hino"]<-NA
discharge_long$discharge[discharge_long$discharge==0 & discharge_long$river=="Hii"]<-NA
discharge_long$discharge[discharge_long$discharge==0 & discharge_long$river=="Gono"]<-NA
discharge_long$discharge[discharge_long$discharge==0 & discharge_long$river=="Takatsu"]<-NA
discharge_long$discharge[discharge_long$discharge==0 & discharge_long$river=="Ohota"]<-NA
discharge_long$discharge[discharge_long$discharge==0 & discharge_long$river=="Oze"]<-NA
discharge_long$discharge[discharge_long$discharge==0 & discharge_long$river=="Yoshino"]<-NA
discharge_long$discharge[discharge_long$discharge==0 & discharge_long$river=="Hiji"]<-NA
discharge_long$discharge[discharge_long$discharge==0 & discharge_long$river=="Naka_Shikoku"]<-NA
discharge_long$discharge[discharge_long$discharge==0 & discharge_long$river=="Shimanto"]<-NA

discharge_long$discharge[is.na(discharge_long$discharge)]<--0.001

#
g<-ggplot(data=discharge_long,aes(x=date2,y=discharge+0.01))+
  geom_hline(yintercept=0.01,colour="#A9A9A9") +
  geom_line(aes(color=paste0(area,drought)))+
  facet_wrap(~river,ncol=4,scales="free_y")+
  scale_color_manual(values=c("#8FBC8F","#FFA07A","#4169E1","#DC143C")) +
  scale_y_log10(limits=c(0.01,2000),labels=label_number()) +
  theme_classic() +
  labs(x="Date",y="Discharge (m3 s-1) + 0.01") +
  theme(aspect.ratio=0.4,text=element_text(size=8),legend.position="")
g
ggsave("/Volumes/HD-ADU3/GIS/Projects/mizukoku/output/PDF/discharge.pdf",g)


