import os
import glob

os.chdir('dir/mizukoku/rawdata/R2事務所用_河川版SHP/')

path1 = os.getcwd()
path2 = glob.glob(path1+"/*/")

import subprocess
from subprocess import PIPE

for i in range(0,len(path2)-1):
  for j in range(0,len(os.listdir(path2[i]))-1):
      os.chdir(path2[i])
      extract_dir = "shapefiles" # サブディレクトリ名
      target_file = os.listdir(path2[i])[j] # 展開するLZHファイル名
      proc = subprocess.run(
      "lha x -f -w={} {}".format(extract_dir,target_file),
      shell=True,
      stdout=PIPE,
      stderr=PIPE,
      )


